#!/bin/bash

d1="top1"
d2="top2"
d3="top3"


myArray=($d1 $d2 $d3)

i=0;

for str in ${myArray[@]}; do
	
	i=$((i+1))
	
	#make topology directory
	mkdir $str
	cd $str
	
	#make note stating topology coding
	echo "Topology_"$i >> "T_"$i
	
	cd ..
	
	#copy commons and main into every topology directory
	cp -Ri commons $str/commons
	cp -i main.cu $str/main.cu
	
done

#remove the extra files
rm -R commons
rm main.cu

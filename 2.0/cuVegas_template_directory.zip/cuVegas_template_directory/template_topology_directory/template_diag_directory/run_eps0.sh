#!/bin/bash 
 
MAXEVAL="" 
 
cd eps0 
 
for i in $(seq 0 19); do 
	 ./eps0_$i $MAXEVAL
done 
 
cd .. 

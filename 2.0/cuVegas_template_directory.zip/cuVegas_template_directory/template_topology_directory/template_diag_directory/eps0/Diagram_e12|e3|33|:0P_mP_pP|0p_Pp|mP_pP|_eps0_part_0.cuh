#ifndef CONFIG_CUH
#define CONFIG_CUH
#include "commons/functions.cuh"
#define _USE_MATH_DEFINES
#include <math.h>


//vegas settings
long int MAXEVAL_MANUAL = 1000000;
int max_it = 20;
int skip = 5;
long int max_batch_size = 1048576;

//vegas map
const int n_intervals = 1024;
double alpha = 0.5;

//vegas stratification
double beta = 0.75;

//blocks
const int blockSizeRes = 64;
const int blockSizeRed = 128;
const int blockSizeUpd = 128;
const int blockSizeFill = 64;
const int blockSizeIntervals = 128;
const int blockSizeInit = 128;

//integrand
const int n_dim = 1;

__host__ __device__ double integrand(double* xx) {


	double f;
	f = 1*xx[0];

	return f;
}

std::string PATH = "/home/matej/Dokumenty/cuvegas/mytest/test.out";
std::string PREFACTOR = "-tgamma(3*eps)*u0^6*((4*Pi)^(9-3*eps))^(-1)*t^(-3*eps)";

#endif

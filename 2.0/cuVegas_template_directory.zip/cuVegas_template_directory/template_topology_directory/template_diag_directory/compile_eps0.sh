#!bin/bash

XFLAGS="-fopenmp -DUSE_NVTX"
NVCCFLAGS="-arch=native -m64 -O3 -rdc=true -lnvToolsExt"

str="e12|e3|33|:0P_mP_pP|0p_Pp|mP_pP|"

cd eps0

nvcc -c $NVCCFLAGS commons/functions.cu -o functions.o

for i in $(seq 0 1); do 
	filename="Diagram_"$str"_eps0_part_"$i".cuh"
	mv $filename config.cuh
	nvcc -Xcompiler=$XFLAGS $NVCCFLAGS functions.o main.cu -o eps0_$i
	mv config.cuh $filename
done 

rm functions.o

cd ..

#!/bin/bash

d1="e1"
d2="e2"
d3="e3"


myArray=($d1 $d2 $d3)

i=0;

for str in ${myArray[@]}; do
	
	i=$((i+1))
	
	#make diagram directory
	mkdir $str
	cd $str
	
	#make note stating diagrams coding
	echo "d"$i> "d"$i
	
	#make coefficient directories
	mkdir eps0
	mkdir eps1
	cd ..
	
	#copy commons and main into every eps directory
	cp -Ri commons $str/eps0/commons
	cp -i main.cu $str/eps0/main.cu
	
	#cp -Ri commons $str/eps1/commons
	#cp -i main.cu $str/eps1/main.cu
	
done

#remove the extra files
rm -R commons
rm main.cu
